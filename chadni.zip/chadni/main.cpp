#include <windows.h>
#include <GL/glut.h>
#include <stdio.h>
#include <math.h>
#define PI 3.14159265358979323846

void renderBitmapString(float x, float y, float z, void *font, const char *string)
{
    const char *c;
    glRasterPos3f(x, y, z);
    for (c = string; *c != '\0'; c++)
    {
        glutBitmapCharacter(font, *c);
    }
}

GLfloat position1 = 0.0f;
GLfloat speed1 = 0.08f;

GLfloat position2 = 0.0f;
GLfloat speed2 = 0.1f;

void update1(int value)
{
    if (position1 > 1.6f)
        position1 = 0.0f;

    position1 += speed1;

    glutPostRedisplay();
    glutTimerFunc(500, update1, 0);
}

void update2(int value)
{
    if (position2 < -1.6f)
        position2 = 0.0f;

    position2 -= speed2;

    glutPostRedisplay();
    glutTimerFunc(1000, update2, 0);
}



void display()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glClear(GL_COLOR_BUFFER_BIT);

    glPointSize(10);

    // Sky

      glColor3f(0.40f, 0.70f, 1.00f);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, 1.0f);
    glVertex2f(-1.0f, 0.2f);
    glVertex2f(1.0f, 0.2f);
    glVertex2f(1.0f, 1.0f);
    glEnd();

    // Sun

          {

int i;

	GLfloat x=0.4f; GLfloat y=0.8f; GLfloat radius =0.1f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.90f, 0.40f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

// Mosjid background building

glColor3f(1.0f, 0.6f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.52f, 0.8f);
    glVertex2f(0.52f, 0.2f);
    glVertex2f(0.8f, 0.2f);
    glVertex2f(0.8f, 0.8f);
    glEnd();

  glColor3f(0.71f, 0.40f, 0.11f);
    glBegin(GL_QUADS);
    glVertex2f(0.8f, 0.6f);
    glVertex2f(0.8f, 0.2f);
    glVertex2f(1.0f, 0.2f);
    glVertex2f(1.0f, 0.6f);
    glEnd();

    // Background building left window


  glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.56f, 0.72f);
    glVertex2f(0.56f, 0.64f);
    glVertex2f(0.64f, 0.64f);
    glVertex2f(0.64f, 0.72f);
    glEnd();

     glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.56f, 0.56f);
    glVertex2f(0.56f, 0.48f);
    glVertex2f(0.64f, 0.48f);
    glVertex2f(0.64f, 0.56f);
    glEnd();

     glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.56f, 0.4f);
    glVertex2f(0.56f, 0.32f);
    glVertex2f(0.64f, 0.32f);
    glVertex2f(0.64f, 0.4f);
    glEnd();

    // Building right window

     glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.72f);
    glVertex2f(0.68f, 0.64f);
    glVertex2f(0.76f, 0.64f);
    glVertex2f(0.76f, 0.72f);
    glEnd();

     glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.56f);
    glVertex2f(0.68f, 0.48f);
    glVertex2f(0.76f, 0.48f);
    glVertex2f(0.76f, 0.56f);
    glEnd();

     glColor3f(1.0f, 0.85f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(0.68f, 0.4f);
    glVertex2f(0.68f, 0.32f);
    glVertex2f(0.76f, 0.32f);
    glVertex2f(0.76f, 0.4f);
    glEnd();

    // Orange building middle line

          glColor3f(1.0f, 1.0f, 1.0f);

    glLineWidth(5.0f);


glBegin(GL_LINES);

        glVertex2f(0.66f, 0.0f);
        glVertex2f(0.66f, 0.8f);

        // Brown building line

        glBegin(GL_LINES);

        glVertex2f(0.8f, 0.52f);
        glVertex2f(1.0f, 0.52f);

        glBegin(GL_LINES);

        glVertex2f(0.8f, 0.4f);
        glVertex2f(1.0f, 0.4f);

        glBegin(GL_LINES);

        glVertex2f(0.9f, 0.2f);
        glVertex2f(0.9f, 0.6f);


glEnd();

    // Mosjid background blue

      {

int i;

	GLfloat x=0.0f; GLfloat y=0.0f; GLfloat radius =0.55f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.10f, 0.20f, 0.70f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

      {

int i;

	GLfloat x=-0.8f; GLfloat y=0.12f; GLfloat radius =0.55f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.10f, 0.20f, 0.70f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

    {

int i;

	GLfloat x=0.8f; GLfloat y=-0.0f; GLfloat radius =0.35f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.10f, 0.20f, 0.70f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

   // first tree green

      {

int i;

	GLfloat x=-0.72f; GLfloat y=0.6f; GLfloat radius =0.15f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.13f, 0.55f, 0.13f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     {

int i;

	GLfloat x=-0.64f; GLfloat y=0.48f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.13f, 0.55f, 0.13f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     {

int i;

	GLfloat x=-0.78f; GLfloat y=0.48f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.13f, 0.55f, 0.13f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

// First tree quad

glColor3f(0.55f, 0.27f, 0.07f);
    glBegin(GL_QUADS);
    glVertex2f(-0.76f, 0.52f);
    glVertex2f(-0.76f, -0.2f);
    glVertex2f(-0.72f, -0.2f);
    glVertex2f(-0.72f, 0.52f);
    glEnd();

    // Second tree green

         {

int i;

	GLfloat x=-0.9f; GLfloat y=0.46f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.13f, 0.55f, 0.13f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}


// Second tree quad

glColor3f(0.55f, 0.27f, 0.07f);
    glBegin(GL_QUADS);
    glVertex2f(-0.88f, 0.4f);
    glVertex2f(-0.88f, -0.2f);
    glVertex2f(-0.84f, -0.2f);
    glVertex2f(-0.84f, 0.4f);
    glEnd();

// Mosjid left background grass
// first grass
  {

int i;

	GLfloat x=-0.92f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

  {

int i;

	GLfloat x=-0.76f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

  {

int i;

	GLfloat x=-0.84f; GLfloat y=-0.12f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

// Second grass

 {

int i;

	GLfloat x=-0.68f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.50f, 0.85f, 0.50f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

 {

int i;

	GLfloat x=-0.6f; GLfloat y=-0.17f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.50f, 0.85f, 0.50f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

// Third grass


 {

int i;

	GLfloat x=0.68f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.50f, 0.85f, 0.50f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

 {

int i;

	GLfloat x=0.6f; GLfloat y=-0.17f; GLfloat radius =0.13f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.50f, 0.85f, 0.50f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

// fourth grass

{

int i;

	GLfloat x=0.92f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

  {

int i;

	GLfloat x=0.76f; GLfloat y=-0.2f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

  {

int i;

	GLfloat x=0.84f; GLfloat y=-0.12f; GLfloat radius =0.09f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(0.0f, 0.39f, 0.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}


    // Mosjid under grass

     glColor3f(0.20f, 0.60f, 0.20f);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -0.24f);
    glVertex2f(-1.0f, -0.52f);
    glVertex2f(1.0f, -0.52f);
    glVertex2f(1.0f, -0.24f);
    glEnd();

   glColor3f(0.3f, 0.7f, 0.3f);
    glBegin(GL_QUADS);
    glVertex2f(-0.1f, -0.4f);
    glVertex2f(-0.06f, -0.6f);
    glVertex2f(0.06f, -0.6f);
    glVertex2f(0.1f, -0.4f);
    glEnd();


    // Mosjid under black block

      glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.56f, -0.36f);
    glVertex2f(-0.6f, -0.4f);
    glVertex2f(0.6f, -0.4f);
    glVertex2f(0.56f, -0.36f);
    glEnd();



// Mosjid

    glColor3f(0.36f, 0.25f, 0.20f);
    glBegin(GL_QUADS);
    glVertex2f(-0.52f, -0.24f);
    glVertex2f(-0.56f, -0.36f);
    glVertex2f(0.56f, -0.36f);
    glVertex2f(0.52f, -0.24f);
    glEnd();

    // Left

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(-0.52f, 0.2f);
    glVertex2f(-0.52f, -0.24f);
    glVertex2f(-0.2f, -0.24f);
    glVertex2f(-0.2f, 0.2f);
    glEnd();

    // Left First piller

      {

int i;

	GLfloat x=-0.5f; GLfloat y=0.61f; GLfloat radius =0.02f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}


     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(-0.52f, 0.6f);
    glVertex2f(-0.52f, -0.2f);
    glVertex2f(-0.48f, -0.2f);
    glVertex2f(-0.48f, 0.6f);
    glEnd();


    // second piller

      {

int i;

	GLfloat x=-0.41f; GLfloat y=0.49f; GLfloat radius =0.03f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}


     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(-0.44f, 0.48f);
    glVertex2f(-0.44f, -0.2f);
    glVertex2f(-0.38f, -0.2f);
    glVertex2f(-0.38f, 0.48f);
    glEnd();

    // Third piller

      {

int i;

	GLfloat x=-0.28f; GLfloat y=0.32f; GLfloat radius =0.06f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(-0.34f, 0.32f);
    glVertex2f(-0.34f, -0.2f);
    glVertex2f(-0.22f, -0.2f);
    glVertex2f(-0.22f, 0.32f);
    glEnd();

    // Middle

        {

int i;

	GLfloat x=0.0f; GLfloat y=0.52f; GLfloat radius =0.2f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

    glColor3f(0.54f, 0.26f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(-0.2f, 0.48f);
    glVertex2f(-0.2f, -0.24f);
    glVertex2f(0.2f, -0.24f);
    glVertex2f(0.2f, 0.48f);
    glEnd();

    // Right

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(0.2f, 0.2f);
    glVertex2f(0.2f, -0.24f);
    glVertex2f(0.52f, -0.24f);
    glVertex2f(0.52f, 0.2f);
    glEnd();

    // right First piller

          {

int i;

	GLfloat x=0.5f; GLfloat y=0.61f; GLfloat radius =0.02f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(0.52f, 0.6f);
    glVertex2f(0.52f, -0.2f);
    glVertex2f(0.48f, -0.2f);
    glVertex2f(0.48f, 0.6f);
    glEnd();

    // second piller

    {

int i;

	GLfloat x=0.41f; GLfloat y=0.49f; GLfloat radius =0.03f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(0.44f, 0.48f);
    glVertex2f(0.44f, -0.2f);
    glVertex2f(0.38f, -0.2f);
    glVertex2f(0.38f, 0.48f);
    glEnd();

    // Third piller

        {

int i;

	GLfloat x=0.28f; GLfloat y=0.32f; GLfloat radius =0.06f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 0.85f, 0.2f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

     glColor3f(0.59f, 0.29f, 0.00f);
    glBegin(GL_QUADS);
    glVertex2f(0.34f, 0.32f);
    glVertex2f(0.34f, -0.2f);
    glVertex2f(0.22f, -0.2f);
    glVertex2f(0.22f, 0.32f);
    glEnd();

    // White polygon

       glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.14f, 0.2f);
    glVertex2f(-0.14f, -0.24f);
    glVertex2f(0.14f, -0.24f);
    glVertex2f(0.14f, 0.2f);
    glVertex2f(0.0f, 0.34f);
    glEnd();

    // Inside white - brown polygon

        glColor3f(0.54f, 0.26f, 0.00f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.1f, 0.12f);
    glVertex2f(-0.1f, -0.24f);
    glVertex2f(0.1f, -0.24f);
    glVertex2f(0.1f, 0.12f);
    glVertex2f(0.0f, 0.2f);
    glEnd();

    // Inside white-yellow polygon

        glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.06f, 0.0f);
    glVertex2f(-0.06f, -0.24f);
    glVertex2f(0.06f, -0.24f);
    glVertex2f(0.06f, 0.0f);
    glVertex2f(0.0f, 0.08f);
    glEnd();

    // Left white box

   glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.5f, 0.1f);
    glVertex2f(-0.5f, 0.06f);
    glVertex2f(-0.42f, 0.06f);
    glVertex2f(-0.42f, 0.1f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.4f, 0.1f);
    glVertex2f(-0.4f, 0.06f);
    glVertex2f(-0.32f, 0.06f);
    glVertex2f(-0.32f, 0.1f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.3f, 0.1f);
    glVertex2f(-0.3f, 0.06f);
    glVertex2f(-0.22f, 0.06f);
    glVertex2f(-0.22f, 0.1f);
    glEnd();

    // Left box polygon

       glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.5f, -0.04f);
    glVertex2f(-0.5f, -0.16f);
    glVertex2f(-0.42f, -0.16f);
    glVertex2f(-0.42f, -0.04f);
    glVertex2f(-0.46f, 0.0f);
    glEnd();

     glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.4f, -0.04f);
    glVertex2f(-0.4f, -0.16f);
    glVertex2f(-0.32f, -0.16f);
    glVertex2f(-0.32f, -0.04f);
    glVertex2f(-0.36f, 0.0f);
    glEnd();

     glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(-0.3f, -0.04f);
    glVertex2f(-0.3f, -0.16f);
    glVertex2f(-0.22f, -0.16f);
    glVertex2f(-0.22f, -0.04f);
    glVertex2f(-0.26f, 0.0f);
    glEnd();

     // Left white box

   glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.5f, 0.1f);
    glVertex2f(0.5f, 0.06f);
    glVertex2f(0.42f, 0.06f);
    glVertex2f(0.42f, 0.1f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.4f, 0.1f);
    glVertex2f(0.4f, 0.06f);
    glVertex2f(0.32f, 0.06f);
    glVertex2f(0.32f, 0.1f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.3f, 0.1f);
    glVertex2f(0.3f, 0.06f);
    glVertex2f(0.22f, 0.06f);
    glVertex2f(0.22f, 0.1f);
    glEnd();

    // Right box polygon

       glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(0.5f, -0.04f);
    glVertex2f(0.5f, -0.16f);
    glVertex2f(0.42f, -0.16f);
    glVertex2f(0.42f, -0.04f);
    glVertex2f(0.46f, 0.0f);
    glEnd();

     glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(0.4f, -0.04f);
    glVertex2f(0.4f, -0.16f);
    glVertex2f(0.32f, -0.16f);
    glVertex2f(0.32f, -0.04f);
    glVertex2f(0.36f, 0.0f);
    glEnd();

     glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(0.3f, -0.04f);
    glVertex2f(0.3f, -0.16f);
    glVertex2f(0.22f, -0.16f);
    glVertex2f(0.22f, -0.04f);
    glVertex2f(0.26f, 0.0f);
    glEnd();

    // Road upper line

      glColor3f(1.0f, 1.0f, 1.0f);

    glLineWidth(5.0f);


glBegin(GL_LINES);

        glVertex2f(-1.0f, -0.6f);
        glVertex2f(1.0f, -0.6f);


glEnd();

// Road middle line

  glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.92f, -0.78f);
    glVertex2f(-0.92f, -0.82f);
    glVertex2f(-0.76f, -0.82f);
    glVertex2f(-0.76f, -0.78f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.6f, -0.78f);
    glVertex2f(-0.6f, -0.82f);
    glVertex2f(-0.44f, -0.82f);
    glVertex2f(-0.44f, -0.78f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.28f, -0.78f);
    glVertex2f(-0.28f, -0.82f);
    glVertex2f(-0.12f, -0.82f);
    glVertex2f(-0.12f, -0.78f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.04f, -0.78f);
    glVertex2f(0.04f, -0.82f);
    glVertex2f(0.2f, -0.82f);
    glVertex2f(0.2f, -0.78f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.36f, -0.78f);
    glVertex2f(0.36f, -0.82f);
    glVertex2f(0.52f, -0.82f);
    glVertex2f(0.52f, -0.78f);
    glEnd();

     glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.68f, -0.78f);
    glVertex2f(0.68f, -0.82f);
    glVertex2f(0.82f, -0.82f);
    glVertex2f(0.82f, -0.78f);
    glEnd();

    // White line upper grass

     glColor3f(0.0f, 0.39f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-1.0f, -0.52f);
    glVertex2f(-1.0f, -0.595f);
    glVertex2f(1.0f, -0.595f);
    glVertex2f(1.0f, -0.52f);
    glEnd();

    // Red car

    glPushMatrix();
glTranslatef(position1, 0.0f, 0.0f);
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.56f, -0.72f);
    glVertex2f(-0.56f, -0.84f);
    glVertex2f(-0.16f, -0.84f);
    glVertex2f(-0.24f, -0.72f);
    glEnd();

      glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(-0.48f, -0.64f);
    glVertex2f(-0.52f, -0.72f);
    glVertex2f(-0.28f, -0.72f);
    glVertex2f(-0.32f, -0.64f);
    glEnd();

    // Red car tire

            {

int i;

	GLfloat x=-0.48f; GLfloat y=-0.84f; GLfloat radius =0.04f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

            {

int i;

	GLfloat x=-0.28f; GLfloat y=-0.84f; GLfloat radius =0.04f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
	glPopMatrix();

}

    // Yellow car

    glPushMatrix();
glTranslatef(position2, 0.0f, 0.0f);
    glColor3f(1.0f, 1.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex2f(0.12f, -0.8f);
    glVertex2f(0.12f, -0.92f);
    glVertex2f(0.44f, -0.92f);
    glVertex2f(0.44f, -0.76f);
    glVertex2f(0.16f, -0.76f);
    glEnd();

     glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.16f, -0.8f);
    glVertex2f(0.16f, -0.88f);
    glVertex2f(0.2f, -0.88f);
    glVertex2f(0.2f, -0.8f);
    glEnd();

     glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
    glVertex2f(0.24f, -0.8f);
    glVertex2f(0.24f, -0.84f);
    glVertex2f(0.36f, -0.84f);
    glVertex2f(0.36f, -0.8f);
    glEnd();

    // Yellow car tire

                {

int i;

	GLfloat x=0.2f; GLfloat y=-0.92f; GLfloat radius =0.03f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();

}

                {

int i;

	GLfloat x=0.36f; GLfloat y=-0.92f; GLfloat radius =0.03f;
	int triangleAmount = 100; //# of lines used to draw circle

	//GLfloat radius = 0.8f; //radius
	GLfloat twicePi = 2.0f * PI;

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_TRIANGLE_FAN);
		glVertex2f(x, y); // center of circle
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f( x + (radius * cos(i *  twicePi / triangleAmount)),
                        y + (radius * sin(i * twicePi / triangleAmount)) );
		}
	glEnd();
	    glPopMatrix();

}


    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    // FIX: Required for drawing
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);

    glutInitWindowSize(640, 480);
    glutInitWindowPosition(80, 50);
    glutCreateWindow("OpenGL Flags Example");
    glutTimerFunc(100, update1, 0);
    glutTimerFunc(100, update2, 0);

    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}

